package com.example.demo.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.DTO.LoginDTO;
import com.example.demo.DTO.RegDTO;
import com.example.demo.entity.Login;
import com.example.demo.repository.LoginRepo;
import com.example.demo.response.LoginResponse;

import com.example.demo.service.LoginService;

import lombok.RequiredArgsConstructor;

@Service
public class LoginIMPL implements LoginService {
	
	@Autowired
	private LoginRepo loginRepo;
	
	
	@Autowired
    private PasswordEncoder passwordEncoder;
	
	LoginDTO loginDTO;
	
	public String addUser(RegDTO regDTO) {
		Login login = new Login(regDTO.getId(),
				regDTO.getName(),
				regDTO.getEmail(),
				this.passwordEncoder.encode(regDTO.getPassword()),
				regDTO.getNumber(),
				regDTO.getAddress());
		loginRepo.save(login);
		return login.getName();
		
	}   
	
	

	@Override
	public LoginResponse loginEmployee(LoginDTO loginDTO) {
		// TODO Auto-generated method stub
		
		String msg = "";
		 Login login1 = loginRepo.findByEmail(loginDTO.getEmail());
        if (login1 != null) {
            String password = loginDTO.getPassword();
            String encodedPassword = login1.getPassword();
            
            Boolean isPwdRight = passwordEncoder.matches(password, encodedPassword);
            if (isPwdRight) {
                Optional<Login> employee = loginRepo.findOneByEmailAndPassword(loginDTO.getEmail(), encodedPassword);
                if (employee.isPresent()) {
                    return new LoginResponse("Login Success", true);
                } else {
                    return new LoginResponse("Login Failed", false);
                }
            } else {
                return new LoginResponse("password Not Match", false);
            }
        }else {
            return new LoginResponse("Email not exits", false);
        }
	}

}
