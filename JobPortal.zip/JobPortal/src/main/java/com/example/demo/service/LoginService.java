package com.example.demo.service;

import com.example.demo.DTO.LoginDTO;
import com.example.demo.DTO.RegDTO;
import com.example.demo.response.LoginResponse;

public interface LoginService {
	
	String addUser(RegDTO regDTO);
    LoginResponse loginEmployee(LoginDTO loginDTO);

}
